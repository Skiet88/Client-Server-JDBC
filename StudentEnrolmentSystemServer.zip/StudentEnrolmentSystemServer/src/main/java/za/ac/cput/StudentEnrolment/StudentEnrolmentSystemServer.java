/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package za.ac.cput.StudentEnrolment;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author AI Bot2
 */
public class StudentEnrolmentSystemServer {

    private ServerSocket serverSocket;
    private Socket clientSocket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private Object receivedObject;
    private ArrayList<Student> studentList;
    private ArrayList<Admin> adminList;
    ArrayList<Subject> subjectList;
    //private ArrayList<Enrollment> enrollmentList;
    private boolean found = false;
    private Student student;
    private Admin admin;
    private Subject subject;
    private DatabaseDAO dao;
    Enrollment enrollment;

    public StudentEnrolmentSystemServer() {

        System.out.println("After loginGUI");
        Connect();

    }

    //Method to establish the connection and call processClient()
    public void Connect() {
        try {
            serverSocket = new ServerSocket(12345);
            System.out.println("Server is Listening");

            clientSocket = serverSocket.accept();
            System.out.println(clientSocket.getInetAddress() + " is Connected");

            in = new ObjectInputStream(clientSocket.getInputStream());
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            out.flush();
        } catch (IOException ex) {

            JOptionPane.showMessageDialog(null, ex);
        }

        dao = new DatabaseDAO();
        processClient();
    }

    //Method that handles the different requests from the Client
    public void processClient() {
        ArrayList<Enrollment> enrollmentList;

        try {
            while (true) {
                System.out.println("Inside while loop");

                receivedObject = in.readObject();

                System.out.println("Read in receivedObject");

                //Validate student and admin login details
                if (receivedObject instanceof String && ((String) receivedObject).equals("Validate")) {
                    System.out.println("Received validate Request");

                    String loginAttempt;
                    //Read the student Object recieved from the Gui
                    receivedObject = in.readObject();
                    System.out.println("read in Object to validate");

                    //validate student details
                    if (receivedObject instanceof Student) {
                        student = (Student) receivedObject;
                        System.out.println("Validate this student:" + student);
                        loginAttempt = dao.verifyStudent(student);
                        out.writeObject(loginAttempt);
                        out.flush();
                        System.out.println("Sent LoginAttempt response:" + loginAttempt);
                        //validate admin details
                    } else if (receivedObject instanceof Admin) {
                        admin = (Admin) receivedObject;
                        loginAttempt = dao.verifyAdmin(admin);
                        out.writeObject(loginAttempt);
                        out.flush();
                    }
                }
                    //Save Student in the database
                 else if (receivedObject instanceof Student) {
                    System.out.println("Received Student Object to save student");
                    Student newstudent = (Student) receivedObject;  
                    String savingAttempt = dao.saveStudent(newstudent);
                    out.writeObject(savingAttempt);
                    out.flush();

                } 
                
                //add Enrollment
                else if (receivedObject instanceof Enrollment) {
                    enrollment = (Enrollment) receivedObject;
                    String response = dao.saveEnrollment(enrollment);
                    out.writeObject(response);
                    out.flush();

                       
                } //Delete Student from the database 
                else if (receivedObject instanceof String && ((String) receivedObject).startsWith("DeleteStudent")) {
                    String stdNum = ((String) receivedObject).substring(13);
                    System.out.println(stdNum);
                    dao.deleteSubject(stdNum);

                    
                } //Delete Subject from the database    
                else if (receivedObject instanceof String && ((String) receivedObject).startsWith("DeleteSubject")) {
                    String subject = ((String) receivedObject).substring(13);
                    System.out.println(subject);
                    dao.deleteSubject(subject);
                } //Cancel Student enrollment
                else if (receivedObject instanceof String && ((String) receivedObject).startsWith("CancelEnroll")) {
                    System.out.println("Received cancelEnrollemnt Request");
                    String cancelEnrollment = ((String) receivedObject).substring(12);
                    String[] separateStrings = cancelEnrollment.split("#");
                    String studentID = separateStrings[0];
                    System.out.println(studentID);
                    String subjectCode = separateStrings[1];
                    System.out.println(subjectCode);

                    dao.deleteEnrollment(studentID, subjectCode);
                    out.writeObject(dao.deleteEnrollment(studentID, subjectCode));
                    out.flush();

                } //Save Subject in the database
                else if (receivedObject instanceof Subject) {
                    System.out.println("Received Subject Object to save subject");
                    subject = (Subject) receivedObject;
                    dao.addSubject(subject);

                    //Retrieve all students from the database    
                } else if (receivedObject instanceof String && ((String) receivedObject).equals("getAllStudents")) {
                    studentList = (ArrayList<Student>) dao.getAllStudents().clone();
                    out.writeObject(studentList);
                    out.flush();

                    //Retrieve all subjects from the database
                } else if (receivedObject instanceof String && ((String) receivedObject).equals("retrieveSubjects")) {
                    subjectList = dao.getAllSubjects();
                    out.writeObject(subjectList);
                    out.flush();
                    //Retrieve all enrollments from the database
                } else if (receivedObject instanceof String && ((String) receivedObject).equals("retrieveEnrollments")) {
                    System.out.println("Received getAll enrollment Request");
                    enrollmentList = (ArrayList<Enrollment>) dao.getAllEnrollment().clone();
                    out.writeObject(enrollmentList);
                    out.flush();
                } else if (receivedObject instanceof String && ((String) receivedObject).startsWith("fetch#")) {

                    String[] command = ((String) receivedObject).split("#");

                    String stdNo = command[1];
                    System.out.println(stdNo);
                    ArrayList<Student> students = dao.getAllStudents();

                    for (int i = 0; i < students.size(); i++) {
                        if (students.get(i).getStddNum().equalsIgnoreCase(stdNo)) {
                            out.writeObject(students.get(i));
                            System.out.println("sent: " + students.get(i).toString());
                            out.flush();
                        }
                    }
                } //Search for student from the database    
                else if (receivedObject instanceof String && ((String) receivedObject).startsWith("searchStudent")) {
                    ArrayList<Subject> enrolledSubjects = new ArrayList();
                    subjectList = dao.getAllSubjects();

                    String studentNum = ((String) receivedObject).substring(13);
                    System.out.println(studentNum);
                    enrollmentList = (ArrayList<Enrollment>) dao.getAllEnrollment();
                    for (int i = 0; i < enrollmentList.size(); i++) {

                        if (enrollmentList.get(i).getStudentNumber().equals(studentNum)) {

                            for (int j = 0; j < subjectList.size(); j++) {
                                System.out.println(enrollmentList.get(i).getStudentNumber());
                                if ((enrollmentList.get(i).getSubjectCode()).equalsIgnoreCase(subjectList.get(j).getSubjectCode())) {
                                    enrolledSubjects.add(subjectList.get(j));

                                }
                            }

                        }
                    }
                    out.writeObject(enrolledSubjects);
                    out.flush();
                } //Search for subject from the database
                else if (receivedObject instanceof String && ((String) receivedObject).startsWith("searchSubject")) {
                    ArrayList<Student> studentsForSubject = new ArrayList();
                    studentList = dao.getAllStudents();
                    String subjectCode = ((String) receivedObject).substring(13);

                    System.out.println(subjectCode);
                    enrollmentList = (ArrayList<Enrollment>) dao.getAllEnrollment();
                    for (int i = 0; i < enrollmentList.size(); i++) {
                        if (enrollmentList.get(i).getSubjectCode().equalsIgnoreCase(subjectCode)) {

                            for (int j = 0; j < studentList.size(); j++) {
                                if ((enrollmentList.get(i).getStudentNumber()).equalsIgnoreCase(studentList.get(j).getStddNum())) {
                                    studentsForSubject.add(studentList.get(j));

                                }
                            }

                        }
                    }
                    out.writeObject(studentsForSubject);
                    out.flush();
                }

            }
        } catch (IOException ex) {
            System.out.println("Error: " + ex);;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }
//Close all connections, streams and sockets.

    public void closeConnection() {
        try {
            in.close();
            out.close();
            clientSocket.close();
            serverSocket.close();
            System.out.println("Server Closed connection");
            // System.exit(0);
        } catch (IOException ex) {
            System.out.println("ERROR: " + ex);
        }
    }

    public static void main(String[] args) {
        new StudentEnrolmentSystemServer();
    }

}
