package za.ac.cput.StudentEnrolment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnection {
    
    public static Connection startConnection() throws SQLException{
     String username = "Admin1";
     String password = "password";
     String url = "jdbc:derby://localhost:1527/StudentEnrollSystem";
     
     Connection con = DriverManager.getConnection(url, username, password);
        
    return con;
    }
    
}
