package za.ac.cput.StudentEnrolment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import za.ac.cput.StudentEnrolment.DBConnection;

public class DatabaseDAO {

    private Connection con;
    private Statement stmt;
    private PreparedStatement ptmt;
    private ResultSet rs;

    public DatabaseDAO() {
        try {
            this.con = DBConnection.startConnection();
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        }

    }

    public String verifyStudent(Student student) {
        boolean found = false;
        try {
            ArrayList<Student> students = new ArrayList();

            String sqlCommand = "SELECT * FROM Student";
            stmt = con.createStatement();
            rs = stmt.executeQuery(sqlCommand);

            if (rs != null) {
                while (rs.next()) {

                    String studNum = rs.getString("std_Num");
                    String studPassword = rs.getString("std_Password");

                    students.add(new Student(studNum, studPassword));

                }

            }
            for (int i = 0; i < students.size(); i++) {
                if ((students.get(i).getStddNum().equals(student.getStddNum())) && (students.get(i).getStdPassword().equals(student.getStdPassword()))) {
                    found = true;

                }
                if (found = true) {
                    return "valid";
                } else {
                    return "invalid";
                }
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        }
        return null;
    }

    public String verifyAdmin(Admin admin) {
        try {
            ArrayList<Admin> admins = new ArrayList();

            String sqlCommand = "SELECT * FROM Admin";
            stmt = con.createStatement();
            rs = stmt.executeQuery(sqlCommand);

            if (rs != null) {
                while (rs.next()) {

                    String adminNum = rs.getString("admin_username");
                    String adminPassword = rs.getString("admin_Password");

                    admins.add(new Admin(adminNum, adminPassword));

                }

                for (int i = 0; i < admins.size(); i++) {
                    if ((admins.get(i).getAdminUsername().equals(admin.getAdminUsername())) && (admins.get(i).getAdminPassword().equals(admin.getAdminPassword()))) {
                        return "valid";
                    } else {
                        return "invalid";
                    }

                }

            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        }
        return null;
    }

    public String saveStudent(Student student) {
        int flag;
        String distance;
        try {
            String sqlCommand1 = "INSERT INTO Student values(?,?,?,?)";
            ptmt = con.prepareStatement(sqlCommand1);
            ptmt.setString(1, student.getStddNum());
            ptmt.setString(2, student.getStdName());
            ptmt.setString(3, student.getStdSurname());
            ptmt.setString(4, student.getStdPassword());

            flag = ptmt.executeUpdate();

            if (flag > 0) {
                return "Student successfully Added";
            } else {
                return "There was an error adding student";
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        } catch (Exception ex) {
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                if (ptmt != null) {
                    ptmt.close();
                }
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }

        }
        return null;

    }

    public String saveAdmin(Admin admin) {
        int flag;
        String distance;
        try {
            String sqlCommand1 = "INSERT INTO Admin values(?,?,?,?)";

            ptmt = con.prepareStatement(sqlCommand1);
            ptmt.setString(1, admin.getAdminName());
            ptmt.setString(2, admin.getAdminSurname());
            ptmt.setString(3, admin.getAdminUsername());
            ptmt.setString(4, admin.getAdminPassword());

            flag = ptmt.executeUpdate();

            if (flag > 0) {
                return "Successfully Added Admin";
            } else {
                return "There was an error adding Admin";
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        } catch (Exception ex) {
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                if (ptmt != null) {
                    ptmt.close();
                }
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
            return null;
        }

    }

    public ArrayList<Student> getAllStudents() {
        int flag;
        ArrayList<Student> students = new ArrayList();
        try {

            String sqlcommand = "SELECT * FROM  Student";
            // record = String.format(record, subject.getSubjectCode(), subject.getSubjectDescription());
            stmt = con.createStatement();
            rs = stmt.executeQuery(sqlcommand);
            if (rs != null) {
                while (rs.next()) {
                    String stdNum = rs.getString(1);
                    String stdName = rs.getString(2);
                    String stdSurname = rs.getString(3);
                    String stdPassword = rs.getString(4);
                    students.add(new Student(stdName, stdSurname, stdNum, stdPassword));

                }
                rs.close();
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        } catch (Exception ex) {
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
        }
        return students;
    }

    public Subject addSubject(Subject subject) {
        int flag;
        try {

            String record = "insert into SUBJECT VALUES(?, ?, ?)";

            ptmt = con.prepareStatement(record);
            ptmt.setString(1, subject.getSubjectCode());
            ptmt.setString(2, subject.getSubjectName());
            ptmt.setString(3, subject.getDuration());

            flag = ptmt.executeUpdate();

            if (flag > 0) {
                return subject;
            } else {
                return null;
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        } catch (Exception ex) {
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
        }
        return null;
    }

    public ArrayList<Subject> getAllSubjects() {
        int flag;
        ArrayList<Subject> subjects = new ArrayList();
        try {

            String sqlcommand = "SELECT * FROM  SUBJECT";
            stmt = con.createStatement();
            rs = stmt.executeQuery(sqlcommand);
            if (rs != null) {
                while (rs.next()) {
                    String subjectCode = rs.getString(1);
                    String subjectName = rs.getString(2);
                    String duration = rs.getString(3);
                    subjects.add(new Subject(subjectCode, subjectName, duration));

                }
                rs.close();
            }
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        } catch (Exception ex) {
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
        }
        return subjects;
    }

    public String saveEnrollment(Enrollment enrollment) {
        String sql = "insert into enroll values(?,?,?)";
        int ok;
        try {
            ptmt = con.prepareStatement(sql);

            ptmt.setString(1, enrollment.getStudentNumber());
            ptmt.setString(2, enrollment.getSubjectCode());
            ptmt.setString(3, enrollment.getEnrollmentYear());

            ok = ptmt.executeUpdate();
            if (ok > 0) {
                return "Student " + enrollment.getStudentNumber() + " enrolled for " + enrollment.getSubjectCode() + " successfully";
            } else {
                return "Error Enrolling Student";

            }
        } catch (SQLException ex) {
            System.out.println("Error:" + ex);
        }
        return null;
    }

    public ArrayList<Enrollment> getAllEnrollment() {
        ArrayList<Enrollment> enrollmentList = new ArrayList<>();
        String sql = "select * from enroll";
        ResultSet rs;

        try {
            ptmt = con.prepareStatement(sql);
            rs = ptmt.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    enrollmentList.add(new Enrollment(rs.getString(1), rs.getString(2), rs.getString(3)));
                }
            }
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return enrollmentList;
    }

    public String deleteEnrollment(String studentNum, String subjectID) {
        String sql = "delete from enroll where std_num = ? and subject_code=?";

        try {
            ptmt = con.prepareStatement(sql);
            ptmt.setString(1, studentNum);
            ptmt.setString(2, subjectID);
            ptmt.executeUpdate();

            return "Enrollment cancellation Successful";

        } catch (SQLException ex) {
            System.out.println("Error " + ex);
        }
        return null;
    }

    public String deleteSubject(String subject) {
        String sql = "delete from subject where subject_Code = ?";
        int ok;
        try {
            ptmt = con.prepareStatement(sql);
            ptmt.setString(1, subject);
            ok = ptmt.executeUpdate();
            if (ok > 0) {
                return subject + " deleted Successfully";
            } else {
                return "Couldn't find record to delete";
            }
        } catch (SQLException ex) {
            System.out.println("Error " + ex);
        }
        return null;
    }

    public String deleteStudent(String student) {
        String sql = "delete from student where Std_Num = ?";
        int ok;
        try {
            ptmt = con.prepareStatement(sql);
            ptmt.setString(1, student);
            ok = ptmt.executeUpdate();
            if (ok > 0) {
                return student + " deleted Successfully";
            } else {
                return "Couldn't find record to delete";
            }
        } catch (SQLException ex) {
            System.out.println("Error " + ex);
        }
        return null;
    }

}
